#Here are all the global statements
from random import randint

player_name = 'fred'

#This is for the weapon armory
number1 = randint(1,9)
number2 = randint(1,9)
number3 = randint(1,9)
number4 = randint(1,9)

sword_pressed = False

beer_count = 0

turn = 3

tt = True

blaster = False

boom = False

current_scene = 'main_menu'