Final1
by Frastlin
Version 1.0

Running the game:
The game should run on whatever OS you have, if you use python to run it and not the .exe file.
To learn how to get python go to the second set of directions and do the first step. I don't know anything past that point.

The first set of directions are for windows usage.
1. Extract this file into a location of choice.
2. Click on the Final1.exe file and try to run it.
3. If you get an error read on, if not enjoy the game!
4. if you get an error saying something about needing a DLL, click on w9xpopen.exe and install those files. Make sure that you have the latest service pack installed on your computer.
5. Click on the Final1.exe file once again. If that doesn't work, do the following:

1. Install python 2.7 from: 
http://www.python.org/download/releases/2.7/
2. Once everything is installed you need to change your environment variables (if you are on windows).
3. Press start, go to computer, right click on computer. Arrow up till you hear properties.
4. in properties tab till you hear something about settings.
5. Shift tab till you hear advanced.
6. tab till you hear environment variables.
7. tab 4 times till you hear 'system variables.'
8. arrow down till you hear: 'path;'. (Not pathX or any other path type, just path).
9. Tab twice to edit and hit enter.
10.  Hit right arrow. Type:
;c:\python27\;c:\python27\scripts\
11. Save everything.
12. go to start, programs, accessories, command prompt and hit enter. Open the folder with the py files in it and hit f4. Copy the path and alt tab to the command prompt window. hit:
cd 
and hit paste. It should look like:
cd c:\my_games\final1\py_files
Hit enter and it should now repeat back your path. Now type:
python engine.py
Hit return
and have fun!

S
P
O
I
L
E
R
S
I hate hard text games, so play the game first and if you really can't figure out what to do read this, but these spoilers aren't in order and not all of them are good for your health.
drink that beer man itsh sho good fer ya
look for WEAP, they are really numbers who think they are letters and you need numbers...
Don't fire a big gun in atmosphere
Touch both the swords
clowns are not your friends
Reading personal and private documents is fun and everyone should do it
Don't hit ctrl C, in this client it doesn't mean copy.
4
True is False and False is True, if that's the case than what are you?